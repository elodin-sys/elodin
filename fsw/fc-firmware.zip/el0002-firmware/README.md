# EL0002 firmware

Prebuilt images for the Aleph FC rev 6 (EL0002). Everything goes in over the board's USB-C port.

Needs: `dfu-util`, `openocd` (0.12+), `esptool` (`pip install esptool`) and `python3`. Works on macOS and Linux.

| Path | What |
| --- | --- |
| `probe/build/dap.bin` | Debug probe (U2, STM32G0B1): CMSIS-DAP for the H747, plus the UART3 and UART6 consoles |
| `probe/build/blinky.bin` | G0 first-light test (LEDs only, **no USB**: only SWD gets you back) |
| `selftest/selftest.elf` | H747 board self-test; also the ELRS flashing passthrough |
| `elrs/*.bin` | ExpressLRS 4.1.0, `Unified_ESP32C3_2400_RX`, FCC, Generic C3 2400 layout, no binding phrase, Wi-Fi auto-on off |

Source: EL0002 repo `firmware/` at `fbb2af0` plus the uncommitted self-test.

## 1. Debug probe (G0)

```sh
./probe/flash.sh dfu dap
```

A blank G0 boots into ST's ROM DFU (`0483:df11`). A probe already running `dap` is detached into DFU automatically. Afterwards it enumerates as `1209:0001` with two serial ports, UART3 and UART6. If more than one probe is attached, set `DAP_SERIAL=<serial>`. Run `./probe/flash.sh help` for the SWD commands (bottom pads TP1/TP2).

## 2. H747 self-test (optional)

```sh
openocd -f interface/cmsis-dap.cfg -c "cmsis_dap_backend usb_bulk; transport select swd" \
  -f target/stm32h7x_dual_bank.cfg -c "program selftest/selftest.elf verify reset exit"
```

The results print on the UART3 port at 115200 baud. Keys: `r` reruns, `i` runs the IMX-6 deep test, `s` streams live IMX-6 data.

## 3. ExpressLRS (onboard ESP32-C3)

```sh
./elrs/flash.sh <UART3 port> <UART6 port> [probe serial]
```

The script loads the self-test, switches it into download passthrough, writes the four images and resets the board. The ports:
- **macOS:** `/dev/cu.usbmodem<N>3` and `/dev/cu.usbmodem<N>5`.
- **Linux:** `/dev/serial/by-id/...-if02` and `...-if04`.

Close any terminal that has those ports open first. Afterwards, flash the flight firmware onto the H747.
